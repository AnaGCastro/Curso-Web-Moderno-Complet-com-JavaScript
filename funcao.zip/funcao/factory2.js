function criarProduto(nome,preco){
    return {
        nome,
        preco,
        desconto: 0.1
    }
}

console.log(criarProduto('Notebook',2199.49))
console.log(criarProduto('Celular',3412.02))
console.log(criarProduto('AirPodes',5782.15))
console.log(criarProduto('Smart Watch',6351.01))
