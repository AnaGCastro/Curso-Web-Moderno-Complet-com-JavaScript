// Factory - É uma função que no final a mesma retorna um objeto 


// Factory Simples

function criarPessoa(){
    return {
    nome: 'Ana',
    sobrenome: 'Gonçaves'

    }   

}


console.log(criarPessoa())