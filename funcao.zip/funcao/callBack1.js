const fabricantes = ["Mercedes","Audi", "BMW"]

function imprimir(nome, indice) {
    console.log(`${indice + 1}. ${nome}`)
}

// ideia do callBack - Passar uma função e a mesma é chamada de volta.
// Pode ser chamda váriasvezes ou apenas uma única vez.

fabricantes.forEach(imprimir)
fabricantes.forEach(function(fabricante){
    console.log(fabricante)
})