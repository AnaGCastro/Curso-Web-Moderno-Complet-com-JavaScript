var nome = "Caneta";
var quantidade = 10;
var preco = 6.4;


console.log(nome);
console.log(quantidade);
console.log(preco);
