//console.log é usado para exibir na tela do computador!
console.log("Bom Dia!");
console.log("Boa Tarde!");// mais um exemplo de console.log
//console.log("Boa Noite!");

/*
* Esse é um 
* comentário
* de múltiplas
*linhas!
*/
