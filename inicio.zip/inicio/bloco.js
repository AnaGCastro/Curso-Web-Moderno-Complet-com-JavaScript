{
  console.log("Grey´s Anatomy");
  console.log("The Good Doctor");  
  console.log("Criminal Minds");  
  console.log("NCIS");  
  console.log("CSI");  
  console.log("The Vampire Diaries");  
  console.log("The Originals");  
  console.log("Pretty Little Liars");    
  console.log("Gossip Girl");  
  console.log("How To Get Away With Murder");  
  console.log("H2O Meninas Sereias");  
  console.log("La Casa de Papel");    
  console.log("Teen Wolf");  
}

{
    console.log("Azul");  
    console.log("Preto");  
    console.log("Roxo");  
    console.log("Vermelho");    

}

console.log("Fim!");