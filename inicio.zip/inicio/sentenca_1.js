console.log("Bom Dia!");
console.log("Boa Tarde!");
console.log("Boa Noite!");