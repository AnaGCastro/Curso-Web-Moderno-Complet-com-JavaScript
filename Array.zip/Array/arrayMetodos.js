const pilotos = ['Vettel', 'Alonso', 'Raikkonen', 'Massa',]
pilotos.pop() // massa querou o carro!
console.log(pilotos)


pilotos.push('Verstappen')
console.log(pilotos)

pilotos.shift() // remove o prmeiro elemento da lista
console.log(pilotos)

pilotos.unshift('Hamilton') //adiciona o elemento no começo
console.log(pilotos)


//splice pode adicionar e remoer elementos

//adconar
pilotos.splice(2,0, 'Botas', 'Massa')
console.log(pilotos)

//remover
pilotos.splice(2,1)
console.log(pilotos)

const algunsPilotos1 = pilotos.slice(3) // novo array
console.log(algunsPilotos1)

const algunsPilotos2 = pilotos.slice(1,4)
console.log(algunsPilotos2)
