const nums = [1,2,3,4,5,6,7,8,9,10]

for (x in nums) {
    if (x == 5 ) {
        break // deixa fluir a estrturua de repetição
    }
     console.log(`${x} = ${nums[x]}`)
}

for (y in nums) {
    if (y==5) {
        continue // interrompe a reptição - só age em estrutura de repetção
    }
    console.log(`${x} = ${nums[x]}`)
}