const imprimiResultado = function(nota) {
    if(nota >= 7) {
        console.log('Aprovdo!')
    } else {
        console.log('Reprovado!')
    }
}

imprimiResultado(10)
imprimiResultado(4)
imprimiResultado('Epa!')