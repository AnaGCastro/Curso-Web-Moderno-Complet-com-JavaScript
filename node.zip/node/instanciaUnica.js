// node faz cache

module.exports = {
    valor: 1,
    inc(){
       this.valor++ 
    }
}