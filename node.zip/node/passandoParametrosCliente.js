const saudacoes = require('./passandoParametros')('Ana', 'Lucas', 'Joao')
console.log(saudacoes)