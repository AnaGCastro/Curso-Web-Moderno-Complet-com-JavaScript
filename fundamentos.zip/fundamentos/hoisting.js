// Hoisting é o termo que significa “içamento”, ou “elevação”.
// O Hoisting permite que você execute funções antes das suas declarações. 
console.log('a = ', a)
var a =  2
console.log('a = ', a)