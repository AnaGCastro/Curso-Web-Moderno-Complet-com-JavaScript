// par nome / valor
const saudacao = 'Opa' // Contexto léxico 1

function exec() {
    const saudacao = 'Falaaa' //contexto léxico 2 
    return saudacao
}


// Objetos são grupos ninhados de pares nome/valor

const cliente = {
    nome: 'Ana',
    idade: 32,
    peso: 57,
    endereco: {
        logradoro: ' Rua Benta Pereira',
        numero:140,

    }

}

console.log(saudacao)
console.log(exec())
console.log(cliente)