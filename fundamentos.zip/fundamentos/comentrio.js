//  Comentário de uma liha
console.log('Linha 1')



/*

Comentário de 
multiplas lihas
*/

console.log('Linha 2')


/*

* Comentário de 
* multiplas lihas
*/

console.log('Linha 3')