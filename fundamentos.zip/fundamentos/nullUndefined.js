let valor //não inicializada
console.log(valor)


valor = null //ausência de valor
console.log(valor)


