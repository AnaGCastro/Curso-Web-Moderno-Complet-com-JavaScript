const raio = 5.6
const area = Math.PI * Math.pow(raio, 2)


console.log(area)
console.log(typeof Math)