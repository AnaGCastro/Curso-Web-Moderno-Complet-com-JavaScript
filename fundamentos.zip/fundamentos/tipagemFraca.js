let qualquer = 'Legal'
console.log(qualquer)
console.log(typeof qualquer)

qualquer = 50
console.log(qualquer)
console.log(typeof qualquer)

// Evitar nomes genéricos e siglas 

let valor = ''
let numero = 1
let pqp = false 
