// no recurso do ES2015
// Destruturação a partir de um objeto

const pessoa ={
    nome: 'Ana',
    idade: 23,
    endereco: {
        logradouro: 'Rua das Flores',
        numero: 1234
    }
}


const {nome, idade } = pessoa
console.log(nome, idade)


const {nome: n, idade: i} = pessoa
console.log(n,i)


const{sobrenome, bemHumorada = true} = pessoa
console.log(sobrenome, bemHumorada)
